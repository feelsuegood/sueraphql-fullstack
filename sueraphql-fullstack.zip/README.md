# SueraPhQL Project

A full-stack web application built with React and GraphQL.

## Project Structure

```
sueraphql/
├── client/          # React frontend application
│   ├── public/      # Static files
│   └── src/         # Source files
│       └── routes/  # React router routes
├── server/          # Backend server
└── docker/          # Docker configuration files
```

## Technologies Used

- **Frontend**:

  - React
  - React Router
  - Create React App

- **Backend**:

  - Node.js
  - GraphQL

- **DevOps**:
  - Docker
  - Docker Compose

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- Docker and Docker Compose
- npm or yarn

### Installation

1. Clone the repository:

```bash
git clone [your-repository-url]
cd sueraphql
```

2. Start the application using Docker:

```bash
# For first time setup
docker compose up --build

# For subsequent runs
docker compose up
```

### Development Setup

#### Frontend (Client)

```bash
cd client
npm install
npm start
```

The frontend will be available at http://localhost:3000

#### Backend (Server)

```bash
cd server
npm install
npm start
```

The backend server will be available at http://localhost:4000

## Available Scripts

### Client

- `npm start`: Runs the app in development mode
- `npm test`: Launches the test runner
- `npm run build`: Builds the app for production
- `npm run eject`: Ejects from Create React App

## Docker Configuration

The project includes Docker configuration for both development and production environments:

- `docker-compose.yml`: Production configuration
- `docker-compose.dev.yml`: Development configuration

### Ports

- Frontend: 3000
- Backend: 4000

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.
